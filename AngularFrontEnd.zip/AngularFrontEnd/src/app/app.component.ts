import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Employee Management Portal';
  constructor(private employeeService: EmployeeService, private router: Router) { }
  logout()
  {
    //alert('logout');
    this.employeeService.logout();
    this.router.navigate(['/login']);
  }
}
