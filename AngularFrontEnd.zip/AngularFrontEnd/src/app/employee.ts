export class Employee{
    id:number=0;
    firstName:string="";
    lastName:string="";
    emailId:string="";
}