import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { User } from '../user';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: User = new User();
  submitted = false;
  message!: string;
 
  

  ngOnInit(): void {
  }

  newUser(): void {
    this.submitted = false;
    this.user = new User();
  }
  constructor(private employeeService: EmployeeService, private router: Router) { }

  onSubmit() {
    this.submitted = true;
    this.validate();    
  }

  validate() {
   // alert(this.user.username);
    this.employeeService.validateEmployee(this.user).subscribe(data => {
   
     //console.log(data+" "+this.user)
    if(data!=null)
    {
    
    this.router.navigate(['/employees']);
    }
    else
    {
    this.router.navigate(['/login']);
    this.message="Invalid Credentials....Try again!";
    this.user = new User();
    }
    },
   error => console.log(error)
   
   );
  }

 
}
