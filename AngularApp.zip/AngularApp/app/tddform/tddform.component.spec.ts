import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TddformComponent } from './tddform.component';

describe('TddformComponent', () => {
  let component: TddformComponent;
  let fixture: ComponentFixture<TddformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TddformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TddformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
