export class Employee{
    id:number=0;
    name:string="";
    email:string="";
    gender:string="";
}